<template>
  <div>
    <div v-if="isExpired" class="fixed bottom-11 right-1 md:right-[60px] z-[93]">
      <div class="bg-[#003c4e] shadow-lg border rounded-md border-[#003c4e] w-auto md:w-[395px] p-6">
        <h4 class="text-[#EE4B5A]">🍪 ยอมรับคุกกี้และนโยบายความเป็นส่วนตัว ?</h4>
        <div class="text-[#fff] text-sm mt-2">
          กรมสุขภาพจิต กระทรวงสาธารณสุข จะนำข้อมูลที่ “คุกกี้” ได้บันทึกหรือเก็บรวบรวมไว้ ไปใช้ในการวิเคราะห์เชิงสถิติ หรือในกิจกรรมอื่นของ กรมสุขภาพจิต เพื่อ ปรับปรุงคุณภาพการให้บริการของ กรมสุขภาพจิต
          <a href="https://pdpa.dmh.go.th/policy/cookies-policy.asp" target="_blank" class="text-[#EE4B5A]" >อ่านเพิ่มเติม</a>
        </div>

        <div class="mt-4" v-if="isDetail">
          <h4 class="text-[#EE4B5A]">คุกกี้ที่เราใช้</h4>
          <div class="text-[#fff] text-[16px] pl-4">คุกกี้ที่มีความจำเป็น (Strictly Necessary Cookies)</div>
          <div class="text-[#ccc] text-[14px] pl-4">คุกกี้ประเภทนี้มีความจำเป็นต่อการให้บริการเว็บไซต์ของ เพื่อให้ท่านสามารถเข้าใช้งานในส่วนต่าง ๆ ของเว็บไซต์ได้ รวมถึงช่วยจดจำข้อมูลที่ท่านเคยให้ไว้ผ่านเว็บไซต์ การปิดการใช้งานคุกกี้ประเภทนี้จะส่งผลให้ท่านไม่สามารถใช้บริการในสาระสำคัญของ ซึ่งจำเป็นต้องเรียกใช้คุกกี้ได้</div>

          <div class="text-[#fff] text-[16px] pl-4 mt-4">คุกกี้เพื่อการวิเคราะห์และประเมินผลการใช้งาน (Performance Cookies)</div>
          <div class="text-[#ccc] text-[14px] pl-4">คุกกี้ประเภทนี้ช่วยให้ ทราบถึงการปฏิสัมพันธ์ของผู้ใช้งานในการใช้บริการเว็บไซต์ของ รวมถึงหน้าเพจหรือพื้นที่ใดของเว็บไซต์ที่ได้รับความนิยม ตลอดจนการวิเคราะห์ข้อมูลด้านอื่น ๆ ยังใช้ข้อมูลนี้เพื่อการปรับปรุงการทำงานของเว็บไซต์ และเพื่อเข้าใจพฤติกรรมของผู้ใช้งานมากขึ้น ถึงแม้ว่า ข้อมูลที่คุกกี้นี้เก็บรวบรวมจะเป็นข้อมูลที่ไม่สามารถระบุตัวตนได้ และนำมาใช้วิเคราะห์ทางสถิติเท่านั้น การปิดการใช้งานคุกกี้ประเภทนี้จะส่งผลให้ ไม่สามารถทราบปริมาณผู้เข้าเยี่ยมชมเว็บไซต์ และไม่สามารถประเมินคุณภาพการให้บริการได้</div>
        </div>

        <div class="flex flex-row justify-end gap-3 mt-3">
          <div @click="accept" class="text-[16px] rounded bg-[#EE4B5A] text-white py-1.5 px-3 hover:cursor-pointer">ยอมรับคุกกี้</div>
          <div @click="showDetail()" class="text-[16px] rounded text-[#EE4B5A] bg-white py-1.5 px-3 hover:cursor-pointer">คุกกี้ที่เราใช้</div>
        </div>
      </div>

    </div>
  </div>
</template>
<script>


export default {
  data() {
    return {
      showModal: false,
      isLoading: false,
      isDetail: false,
      item_question: [],
      isExpired: false,
      form: {
        gender: '',
        age: '',
        qualification: '',
        work: '',
        workDis: '',
      },
    }
  },
  components: {
  },
  mounted() {
   
   const chk = this.getCookie('pdpa_consent');
   if(chk != 'accepted'){
      this.isExpired = true;
   }
  },
  methods: {
    showDetail(){
      this.isDetail = (this.isDetail) ? false : true;
    },
    accept(){
      this.setCookie('pdpa_consent', 'accepted', 365)
      this.isExpired = false;
    },
    setCookie(name, value, days) {
    let expires = ""
    if (days) {
      const date = new Date()
      date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000))
      expires = "; expires=" + date.toUTCString()
    }
    document.cookie = name + "=" + encodeURIComponent(value) + expires + "; path=/"
  },
  getCookie(name) {
    const cookies = document.cookie.split('; ').reduce((acc, cur) => {
      const [k, v] = cur.split('=')
      acc[k] = v
      return acc
    }, {})

    if (!cookies[name]) return null

    const expireAt = cookies[`${name}_expire_at`]
    if (expireAt && Date.now() > parseInt(expireAt)) {
      deleteCookie(name)
      deleteCookie(`${name}_expire_at`)
      return null
    }

    return decodeURIComponent(cookies[name])
  },
  isCookieExpired(name) {
  const expireAt = document.cookie
    .split('; ')
    .find(row => row.startsWith(name + '_expire_at='))
    ?.split('=')[1]
console.log('expireAt',expireAt)
  if (!expireAt) return true
  console.log(expireAt)
  return Date.now() > parseInt(expireAt)
},

   deleteCookie(name) {
    document.cookie = name + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;"
  }
  }
}
</script>