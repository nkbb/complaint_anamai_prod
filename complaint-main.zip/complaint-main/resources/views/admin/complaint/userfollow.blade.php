@extends('layouts.app-admin')

@section('pageTitle', 'ติดตามเรื่องร้องเรียน | ศูนย์รับข้อร้องเรียนและข้อชมเชย กรมอนามัย')

@section('content')
<div class="pt-6 pb-11 px-3 md:px-7 bg-white mb-[80px] mx-4 md:mx-8 lg:mx-16 2xl:mx-[326px] border shadow-md">
  @php
    $title_name = '<div class="text-2xl text-brand-600 md:ml-11 ml-0  mb-6"><i class="far fa-bell"></i> ติดตามเรื่องร้องเรียน</div>';
  @endphp

  <admin-list-complaint
    type="88"
    title_name="{{ $title_name }}"
    unit="{{ json_encode($unit) }}"
    user_level="{{ Auth::user()->level }}"
    is_search="0"
    >
  </admin-list-complaint>

 

</div>
@endsection